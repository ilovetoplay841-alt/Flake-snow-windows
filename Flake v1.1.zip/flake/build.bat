@echo off
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" goto nocsc
set "ICON="
if exist flake.ico set "ICON=/win32icon:flake.ico"
echo Building Flake.exe ...
"%CSC%" /nologo /target:winexe /optimize+ /codepage:65001 /out:Flake.exe %ICON% /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll Flake.cs
if errorlevel 1 goto fail
echo.
echo Done! Starting Flake.exe - look for the snowflake icon in the tray.
start "" "%~dp0Flake.exe"
timeout /t 3 >nul
exit /b 0
:nocsc
echo .NET Framework 4 compiler not found.
pause
exit /b 1
:fail
echo.
echo Build failed. Copy the error text above and send it to Claude.
pause
exit /b 1
