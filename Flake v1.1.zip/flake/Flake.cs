// Flake — зима на вашем рабочем столе.
// Снег падает поверх рабочего стола, ложится сугробами на окна и панель задач,
// клики проходят сквозь него. Работает в фоне, управление — из значка в трее.
//
// Написано на C# 5 (WinForms + GDI+), чтобы собираться штатным компилятором Windows.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace FlakeSnow
{
    // ------------------------------------------------------------------ WinAPI
    [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; public POINT(int x, int y) { X = x; Y = y; } }
    [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; public SIZE(int x, int y) { cx = x; cy = y; } }
    [StructLayout(LayoutKind.Sequential)]
    struct BLENDFUNCTION { public byte BlendOp, BlendFlags, SourceConstantAlpha, AlphaFormat; }
    [StructLayout(LayoutKind.Sequential)]
    struct BITMAPINFO
    {
        public int biSize, biWidth, biHeight;
        public short biPlanes, biBitCount;
        public int biCompression, biSizeImage, biXPelsPerMeter, biYPelsPerMeter, biClrUsed, biClrImportant;
    }

    static class Native
    {
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int idx);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder sb, int max);
        [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
        [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vk);
        [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
        [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr h, int id);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] public static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize, IntPtr hdcSrc, ref POINT pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
        [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
        [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
        [DllImport("user32.dll")] public static extern bool DestroyIcon(IntPtr h);
        [DllImport("gdi32.dll")] public static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")] public static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] public static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
        [DllImport("gdi32.dll")] public static extern bool DeleteObject(IntPtr obj);
        [DllImport("gdi32.dll")] public static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO bmi, uint usage, out IntPtr bits, IntPtr section, uint offset);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int attr, out RECT r, int size);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int v, int size);
    }

    // ------------------------------------------------------------------ Overlay window
    // Прозрачное окно во весь виртуальный экран: поверх всех, без фокуса, клики проходят сквозь.
    class Overlay : Form
    {
        public event Action<int> HotKey;

        public Overlay()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            Size = new Size(10, 10);
            Location = new Point(-32000, -32000);
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                // LAYERED | TRANSPARENT | TOOLWINDOW | NOACTIVATE | TOPMOST
                cp.ExStyle |= 0x80000 | 0x20 | 0x80 | 0x8000000 | 0x8;
                return cp;
            }
        }

        protected override bool ShowWithoutActivation { get { return true; } }
        protected override void OnPaintBackground(PaintEventArgs e) { }
        protected override void OnPaint(PaintEventArgs e) { }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0312 && HotKey != null) { HotKey(m.WParam.ToInt32()); return; }
            if (m.Msg == 0x0084) { m.Result = new IntPtr(-1); return; } // HTTRANSPARENT
            base.WndProc(ref m);
        }
    }

    // ------------------------------------------------------------------ Model
    class Flake
    {
        public float X, Y, Vy, Sway, Freq, Phase, Pvx, Pvy;
        public int Sz, Al;
        public bool Alive;
    }

    class Puff { public float X, Y, Vx, Vy, Life, Max; public int Sz; public bool Alive; }

    class Snowman { public float X, Scale; public int Hat; public Color Scarf; }

    // Поверхность, на которую ложится снег: окно, панель задач или «земля» внизу монитора.
    class Surface
    {
        public const int B = 3;                 // ширина столбика сугроба, px
        public Rectangle R;                     // положение в координатах оверлея
        public float[] H = new float[0];        // высоты сугроба по столбикам
        public bool Ground;
        public double Seen;
        public List<Snowman> Men = new List<Snowman>();

        public void EnsureBuckets()
        {
            int n = Math.Max(4, R.Width / B);
            if (H.Length != n)
            {
                float[] nh = new float[n];
                Array.Copy(H, nh, Math.Min(n, H.Length));
                H = nh;
            }
        }
    }

    // ------------------------------------------------------------------ App
    class SnowApp : ApplicationContext
    {
        // --- настройки
        int intensity = 1;          // 0 лёгкий, 1 ровный, 2 метель
        int wind = 0;               // -1 влево, 0 нет, 1 вправо
        bool accumulate = true;
        bool paused = false;

        // --- окно и буфер
        Overlay form;
        Rectangle vs;
        int W, H;
        IntPtr memDC, dib, oldBmp, bits;
        Bitmap frame;
        Graphics g;
        bool shown = true;
        bool fullscreen = false;

        // --- UI
        NotifyIcon tray;
        ContextMenuStrip menu;
        ToolStripMenuItem miPause, miAccum, miAuto;
        ToolStripMenuItem[] miInt = new ToolStripMenuItem[3];
        ToolStripMenuItem[] miWind = new ToolStripMenuItem[3];
        System.Windows.Forms.Timer timer;

        // --- симуляция
        const int MaxFlakes = 2600;
        Flake[] flakes = new Flake[MaxFlakes];
        Puff[] puffs = new Puff[600];
        int puffHead = 0, lastActive = 0;
        Bitmap[,] spr = new Bitmap[6, 3];
        float[] sprR = new float[] { 1.1f, 1.7f, 2.4f, 3.4f, 4.8f, 6.8f };
        Random rnd = new Random();
        Stopwatch clock = Stopwatch.StartNew();
        double last = 0, nextCheck = 0, nextTop = 0, nextClean = 0;
        float dpi = 1f, t = 0f, windCur = 0f, drift = 0f;
        bool initialFill = true;
        long frameNo = 0;

        Dictionary<IntPtr, Surface> surf = new Dictionary<IntPtr, Surface>();
        List<Surface> zlist = new List<Surface>();
        Native.EnumWindowsProc enumProc;
        StringBuilder clsBuf = new StringBuilder(80);
        float[] sm = new float[64];
        Color[] palette = new Color[] {
            Color.FromArgb(214, 56, 56), Color.FromArgb(52, 120, 205),
            Color.FromArgb(46, 160, 90), Color.FromArgb(232, 150, 40) };

        const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";

        public SnowApp()
        {
            using (Graphics gs = Graphics.FromHwnd(IntPtr.Zero)) dpi = gs.DpiX / 96f;
            LoadSettings();
            MakeSprites();
            for (int i = 0; i < flakes.Length; i++) flakes[i] = new Flake();
            for (int i = 0; i < puffs.Length; i++) puffs[i] = new Puff();
            enumProc = new Native.EnumWindowsProc(OnWindow);

            form = new Overlay();
            form.HotKey += OnHotKey;
            form.Show();
            Rebuild();
            Native.RegisterHotKey(form.Handle, 1, 0x3, 0x53); // Ctrl+Alt+S
            Native.RegisterHotKey(form.Handle, 2, 0x3, 0x4D); // Ctrl+Alt+M

            BuildTray();
            SystemEvents.DisplaySettingsChanged += OnDisplayChanged;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 15;
            timer.Tick += delegate { try { Frame(); } catch (Exception) { } };
            timer.Start();

            tray.ShowBalloonTip(4000, "Flake",
                "Снег пошёл! Управление — в значке у часов. Смахнуть снег: зажмите Ctrl+Shift и водите курсором.",
                ToolTipIcon.Info);
        }

        // ============================================================ настройки
        string SettingsPath
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    Path.Combine("Flake", "settings.txt"));
            }
        }

        void LoadSettings()
        {
            try
            {
                if (!File.Exists(SettingsPath)) return;
                foreach (string line in File.ReadAllLines(SettingsPath))
                {
                    string[] kv = line.Split('=');
                    int v;
                    if (kv.Length != 2 || !int.TryParse(kv[1], out v)) continue;
                    if (kv[0] == "intensity") intensity = Math.Max(0, Math.Min(2, v));
                    else if (kv[0] == "wind") wind = Math.Max(-1, Math.Min(1, v));
                    else if (kv[0] == "accumulate") accumulate = v != 0;
                }
            }
            catch (Exception) { }
        }

        void SaveSettings()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
                File.WriteAllLines(SettingsPath, new string[] {
                    "intensity=" + intensity, "wind=" + wind, "accumulate=" + (accumulate ? 1 : 0) });
            }
            catch (Exception) { }
        }

        bool GetAutostart()
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey))
                    return k != null && k.GetValue("Flake") != null;
            }
            catch (Exception) { return false; }
        }

        void SetAutostart(bool on)
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(RunKey, true))
                {
                    if (k == null) return;
                    if (on) k.SetValue("Flake", "\"" + Application.ExecutablePath + "\"");
                    else k.DeleteValue("Flake", false);
                }
            }
            catch (Exception) { }
        }

        // ============================================================ буфер кадра
        void FreeBuffers()
        {
            if (g != null) { g.Dispose(); g = null; }
            if (frame != null) { frame.Dispose(); frame = null; }
            if (memDC != IntPtr.Zero)
            {
                if (oldBmp != IntPtr.Zero) Native.SelectObject(memDC, oldBmp);
                Native.DeleteDC(memDC); memDC = IntPtr.Zero;
            }
            if (dib != IntPtr.Zero) { Native.DeleteObject(dib); dib = IntPtr.Zero; }
        }

        void Rebuild()
        {
            FreeBuffers();
            vs = SystemInformation.VirtualScreen;
            W = vs.Width; H = vs.Height;
            form.Bounds = vs;

            IntPtr screenDC = Native.GetDC(IntPtr.Zero);
            memDC = Native.CreateCompatibleDC(screenDC);
            BITMAPINFO bi = new BITMAPINFO();
            bi.biSize = Marshal.SizeOf(typeof(BITMAPINFO));
            bi.biWidth = W; bi.biHeight = -H;       // сверху вниз
            bi.biPlanes = 1; bi.biBitCount = 32;
            dib = Native.CreateDIBSection(screenDC, ref bi, 0, out bits, IntPtr.Zero, 0);
            oldBmp = Native.SelectObject(memDC, dib);
            Native.ReleaseDC(IntPtr.Zero, screenDC);

            frame = new Bitmap(W, H, W * 4, PixelFormat.Format32bppPArgb, bits);
            g = Graphics.FromImage(frame);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.Bilinear;
            g.PixelOffsetMode = PixelOffsetMode.Half;

            surf.Clear();
            zlist.Clear();
            initialFill = true;
            for (int i = 0; i < flakes.Length; i++) flakes[i].Alive = false;
        }

        void OnDisplayChanged(object s, EventArgs e)
        {
            try { form.BeginInvoke(new MethodInvoker(Rebuild)); } catch (Exception) { }
        }

        // ============================================================ спрайты снежинок
        void MakeSprites()
        {
            float[] alphas = new float[] { 0.40f, 0.70f, 1.0f };
            for (int i = 0; i < 6; i++)
                for (int a = 0; a < 3; a++)
                    spr[i, a] = CreateSprite(sprR[i] * dpi, alphas[a]);
        }

        Bitmap CreateSprite(float r, float alpha)
        {
            int S = (int)Math.Ceiling(r * 2.8f) + 2;
            Bitmap b = new Bitmap(S, S, PixelFormat.Format32bppPArgb);
            using (Graphics gg = Graphics.FromImage(b))
            {
                gg.SmoothingMode = SmoothingMode.AntiAlias;
                using (GraphicsPath p = new GraphicsPath())
                {
                    p.AddEllipse(0f, 0f, S - 1f, S - 1f);
                    using (PathGradientBrush pg = new PathGradientBrush(p))
                    {
                        ColorBlend cb = new ColorBlend(3);
                        cb.Colors = new Color[] {
                            Color.FromArgb(0, 255, 255, 255),
                            Color.FromArgb((int)(alpha * 140), 238, 246, 255),
                            Color.FromArgb((int)(alpha * 255), 255, 255, 255) };
                        cb.Positions = new float[] { 0f, 0.45f, 1f };
                        pg.InterpolationColors = cb;
                        gg.FillPath(pg, p);
                    }
                }
            }
            return b;
        }

        // ============================================================ трей
        void BuildTray()
        {
            menu = new ContextMenuStrip();

            ToolStripMenuItem head = new ToolStripMenuItem("Flake — зима на рабочем столе");
            head.Enabled = false;
            menu.Items.Add(head);
            menu.Items.Add(new ToolStripSeparator());

            miPause = new ToolStripMenuItem("Пауза");
            miPause.Click += delegate { TogglePause(); };
            menu.Items.Add(miPause);

            ToolStripMenuItem weather = new ToolStripMenuItem("Погода");
            string[] wn = new string[] { "Лёгкий снег", "Ровный снег", "Метель" };
            for (int i = 0; i < 3; i++)
            {
                int k = i;
                miInt[i] = new ToolStripMenuItem(wn[i]);
                miInt[i].Click += delegate { intensity = k; SaveSettings(); };
                weather.DropDownItems.Add(miInt[i]);
            }
            menu.Items.Add(weather);

            ToolStripMenuItem windMenu = new ToolStripMenuItem("Ветер");
            string[] ww = new string[] { "Влево", "Без ветра", "Вправо" };
            for (int i = 0; i < 3; i++)
            {
                int k = i;
                miWind[i] = new ToolStripMenuItem(ww[i]);
                miWind[i].Click += delegate { wind = k - 1; SaveSettings(); };
                windMenu.DropDownItems.Add(miWind[i]);
            }
            menu.Items.Add(windMenu);

            miAccum = new ToolStripMenuItem("Копить снег на окнах");
            miAccum.Click += delegate { accumulate = !accumulate; SaveSettings(); };
            menu.Items.Add(miAccum);

            menu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem man = new ToolStripMenuItem("Слепить снеговика  (Ctrl+Alt+M)");
            man.Click += delegate { AddSnowman(); };
            menu.Items.Add(man);

            ToolStripMenuItem unman = new ToolStripMenuItem("Убрать снеговиков");
            unman.Click += delegate { foreach (Surface s in surf.Values) s.Men.Clear(); };
            menu.Items.Add(unman);

            ToolStripMenuItem sweep = new ToolStripMenuItem("Смахнуть весь снег");
            sweep.Click += delegate { ClearAllSnow(); };
            menu.Items.Add(sweep);

            menu.Items.Add(new ToolStripSeparator());

            miAuto = new ToolStripMenuItem("Запускать вместе с Windows");
            miAuto.Click += delegate { SetAutostart(!GetAutostart()); };
            menu.Items.Add(miAuto);

            ToolStripMenuItem exit = new ToolStripMenuItem("Выход");
            exit.Click += delegate { Quit(); };
            menu.Items.Add(exit);

            menu.Opening += delegate { RefreshMenu(); };

            tray = new NotifyIcon();
            tray.Icon = MakeIcon();
            tray.Text = "Flake — идёт снег";
            tray.ContextMenuStrip = menu;
            tray.Visible = true;
            tray.DoubleClick += delegate { TogglePause(); };
        }

        void RefreshMenu()
        {
            miPause.Text = paused ? "Продолжить снегопад  (Ctrl+Alt+S)" : "Пауза  (Ctrl+Alt+S)";
            for (int i = 0; i < 3; i++) { miInt[i].Checked = (i == intensity); miWind[i].Checked = (wind == i - 1); }
            miAccum.Checked = accumulate;
            miAuto.Checked = GetAutostart();
        }

        Icon MakeIcon()
        {
            using (Bitmap b = new Bitmap(32, 32, PixelFormat.Format32bppArgb))
            using (Graphics gg = Graphics.FromImage(b))
            {
                gg.SmoothingMode = SmoothingMode.AntiAlias;
                using (LinearGradientBrush br = new LinearGradientBrush(new Rectangle(0, 0, 32, 32),
                    Color.FromArgb(86, 168, 245), Color.FromArgb(30, 74, 168), 90f))
                    gg.FillEllipse(br, 0, 0, 31, 31);
                using (Pen p = new Pen(Color.White, 2.2f))
                {
                    p.StartCap = LineCap.Round; p.EndCap = LineCap.Round;
                    DrawFlakeGlyph(gg, p, 16f, 16f, 11.5f);
                }
                IntPtr hi = b.GetHicon();
                Icon ic = (Icon)Icon.FromHandle(hi).Clone();
                Native.DestroyIcon(hi);
                return ic;
            }
        }

        static void DrawFlakeGlyph(Graphics gg, Pen p, float cx, float cy, float r)
        {
            for (int k = 0; k < 6; k++)
            {
                double a = k * Math.PI / 3.0;
                float ex = cx + (float)Math.Cos(a) * r, ey = cy + (float)Math.Sin(a) * r;
                gg.DrawLine(p, cx, cy, ex, ey);
                float bx = cx + (float)Math.Cos(a) * r * 0.58f, by = cy + (float)Math.Sin(a) * r * 0.58f;
                for (int s = -1; s <= 1; s += 2)
                {
                    double a2 = a + s * 0.9;
                    gg.DrawLine(p, bx, by, bx + (float)Math.Cos(a2) * r * 0.34f, by + (float)Math.Sin(a2) * r * 0.34f);
                }
            }
        }

        void OnHotKey(int id)
        {
            if (id == 1) TogglePause();
            else if (id == 2) AddSnowman();
        }

        void TogglePause()
        {
            paused = !paused;
            ApplyVisibility();
            tray.Text = paused ? "Flake — пауза" : "Flake — идёт снег";
        }

        void ApplyVisibility()
        {
            bool want = !paused && !fullscreen;
            if (want == shown) return;
            shown = want;
            Native.ShowWindow(form.Handle, want ? 4 : 0);   // SW_SHOWNOACTIVATE / SW_HIDE
            timer.Interval = want ? 15 : 200;
            if (want) last = clock.Elapsed.TotalSeconds;
        }

        void Quit()
        {
            timer.Stop();
            SystemEvents.DisplaySettingsChanged -= OnDisplayChanged;
            Native.UnregisterHotKey(form.Handle, 1);
            Native.UnregisterHotKey(form.Handle, 2);
            tray.Visible = false;
            tray.Dispose();
            FreeBuffers();
            form.Close();
            ExitThread();
        }

        // ============================================================ окна
        string ClassOf(IntPtr h)
        {
            clsBuf.Length = 0;
            Native.GetClassName(h, clsBuf, clsBuf.Capacity);
            return clsBuf.ToString();
        }

        Surface GetSurface(IntPtr key)
        {
            Surface s;
            if (!surf.TryGetValue(key, out s)) { s = new Surface(); surf[key] = s; }
            return s;
        }

        bool OnWindow(IntPtr h, IntPtr lp)
        {
            if (h == form.Handle) return true;
            if (!Native.IsWindowVisible(h) || Native.IsIconic(h)) return true;
            int ex = Native.GetWindowLong(h, -20);
            if ((ex & 0x20) != 0) return true;                       // прозрачные для кликов (чужие оверлеи)
            string cls = ClassOf(h);
            if (cls == "Progman" || cls == "WorkerW") return true;   // сам рабочий стол
            bool shell = cls.StartsWith("Shell_");                   // панель задач
            if (!shell)
            {
                if ((ex & 0x80) != 0 && (ex & 0x40000) == 0) return true;   // tool-окна
                if (Native.GetWindowTextLength(h) == 0) return true;
            }
            int cloaked;
            if (Native.DwmGetWindowAttribute(h, 14, out cloaked, 4) == 0 && cloaked != 0) return true;
            RECT r;
            if (Native.DwmGetWindowAttribute(h, 9, out r, Marshal.SizeOf(typeof(RECT))) != 0)
                if (!Native.GetWindowRect(h, out r)) return true;
            int w = r.Right - r.Left, hh = r.Bottom - r.Top;
            if (shell) { if (w < 30 || hh < 30) return true; }
            else if (w < 140 || hh < 60) return true;

            Rectangle lr = new Rectangle(r.Left - vs.X, r.Top - vs.Y, w, hh);
            if (lr.Right <= 0 || lr.Left >= W || lr.Top >= H) return true;

            Surface s = GetSurface(h);
            s.Ground = false;
            s.R = lr;
            s.Seen = lastNow;
            s.EnsureBuckets();
            zlist.Add(s);
            return true;
        }

        double lastNow = 0;

        void BuildSurfaces(double now)
        {
            lastNow = now;
            zlist.Clear();
            Native.EnumWindows(enumProc, IntPtr.Zero);

            Screen[] scr = Screen.AllScreens;
            for (int i = 0; i < scr.Length; i++)
            {
                Rectangle b = scr[i].Bounds;
                Point below = new Point(b.Left + b.Width / 2, b.Bottom + 8);
                bool covered = false;
                for (int k = 0; k < scr.Length; k++)
                    if (k != i && scr[k].Bounds.Contains(below)) covered = true;
                if (covered) continue;                 // под этим монитором есть другой — земли нет
                Surface s = GetSurface(new IntPtr(-(i + 1)));
                s.Ground = true;
                s.R = new Rectangle(b.Left - vs.X, b.Bottom - vs.Y, b.Width, 400);
                s.Seen = now;
                s.EnsureBuckets();
                zlist.Add(s);
            }

            if (now >= nextClean)
            {
                nextClean = now + 5;
                List<IntPtr> dead = new List<IntPtr>();
                foreach (KeyValuePair<IntPtr, Surface> kv in surf)
                    if (now - kv.Value.Seen > 40) dead.Add(kv.Key);
                foreach (IntPtr k in dead) surf.Remove(k);
            }
        }

        bool IsFullscreenForeground()
        {
            IntPtr fg = Native.GetForegroundWindow();
            if (fg == IntPtr.Zero || fg == form.Handle) return false;
            string cls = ClassOf(fg);
            if (cls == "Progman" || cls == "WorkerW" || cls.StartsWith("Shell_")) return false;
            RECT r;
            if (!Native.GetWindowRect(fg, out r)) return false;
            Rectangle b = Screen.FromHandle(fg).Bounds;
            return r.Left <= b.Left && r.Top <= b.Top && r.Right >= b.Right && r.Bottom >= b.Bottom;
        }

        // ============================================================ симуляция
        void Spawn(Flake f, bool initial)
        {
            float lo = Math.Min(0f, -drift), hi = W + Math.Max(0f, -drift);
            f.X = lo + (float)rnd.NextDouble() * (hi - lo);
            f.Y = initial ? (float)rnd.NextDouble() * H : -(float)rnd.NextDouble() * 120f - 6f;
            f.Sz = (int)(Math.Pow(rnd.NextDouble(), 1.7) * 6);
            if (f.Sz > 5) f.Sz = 5;
            f.Al = f.Sz >= 4 ? rnd.Next(0, 2) : rnd.Next(1, 3);
            f.Vy = (34f + f.Sz * 17f + (float)rnd.NextDouble() * 26f) * dpi;
            f.Sway = 5f + (float)rnd.NextDouble() * 16f;
            f.Freq = 0.8f + (float)rnd.NextDouble() * 2f;
            f.Phase = (float)rnd.NextDouble() * 6.28f;
            f.Pvx = 0; f.Pvy = 0;
            f.Alive = true;
        }

        void SpawnPuff(float x, float y, float vx, float vy)
        {
            Puff p = puffs[puffHead];
            puffHead = (puffHead + 1) % puffs.Length;
            p.X = x; p.Y = y; p.Vx = vx; p.Vy = vy;
            p.Max = 0.5f + (float)rnd.NextDouble() * 0.6f; p.Life = p.Max;
            p.Sz = rnd.Next(1, 3); p.Alive = true;
        }

        float CapAt(Surface s, int j)
        {
            float max = (s.Ground ? 28f : 16f) * dpi;
            int edge = Math.Min(j, s.H.Length - 1 - j);
            return Math.Min(max, (edge + 1) * 1.6f * dpi);
        }

        void AddSnow(Surface s, int i, float amt)
        {
            float[] h = s.H; int n = h.Length;
            if (i < 0 || i >= n) return;
            Bump(s, i, amt * 0.5f); Bump(s, i - 1, amt * 0.25f); Bump(s, i + 1, amt * 0.25f);
            float slope = 1.3f * dpi;
            for (int it = 0; it < 3; it++)
                for (int j = Math.Max(1, i - 4); j <= Math.Min(n - 2, i + 4); j++)
                {
                    float d = h[j] - h[j - 1];
                    if (d > slope) { float m = (d - slope) * 0.4f; h[j] -= m; h[j - 1] += m; }
                    d = h[j] - h[j + 1];
                    if (d > slope) { float m = (d - slope) * 0.4f; h[j] -= m; h[j + 1] += m; }
                }
        }

        void Bump(Surface s, int j, float amt)
        {
            if (j < 0 || j >= s.H.Length) return;
            s.H[j] = Math.Min(s.H[j] + amt, CapAt(s, j));
        }

        void Simulate(float dt)
        {
            t += dt;
            float baseW = wind * (intensity == 2 ? 280f : (intensity == 1 ? 70f : 45f));
            float gust = (float)(Math.Sin(t * 0.37) * 18 + Math.Sin(t * 0.91 + 1.3) * 10) * (intensity == 2 ? 3f : 1f);
            windCur += ((baseW + gust) * dpi - windCur) * Math.Min(1f, dt * 1.2f);
            float speedMul = intensity == 0 ? 0.8f : (intensity == 1 ? 1f : 1.7f);
            drift = windCur * 0.8f * (H / (110f * speedMul * dpi));

            int baseCount = intensity == 0 ? 110 : (intensity == 1 ? 280 : 800);
            float cnt = baseCount * (W / 1920f) * (1f + Math.Abs(drift) / W);
            int active = Math.Max(10, Math.Min(MaxFlakes, (int)cnt));
            for (int i = active; i < lastActive; i++) flakes[i].Alive = false;
            lastActive = active;

            // смахивание курсором: Ctrl + Shift
            bool sweeping = (Native.GetAsyncKeyState(0x11) & 0x8000) != 0 && (Native.GetAsyncKeyState(0x10) & 0x8000) != 0;
            POINT cp; Native.GetCursorPos(out cp);
            sweepOn = sweeping; sweepX = cp.X - vs.X; sweepY = cp.Y - vs.Y;
            if (sweeping) Sweep(dt, sweepX, sweepY, active);

            for (int i = 0; i < active; i++)
            {
                Flake f = flakes[i];
                if (!f.Alive) Spawn(f, initialFill);

                f.Phase += dt * f.Freq;
                float vx = windCur * (0.55f + 0.12f * f.Sz) + (float)Math.Sin(f.Phase) * f.Sway * dpi + f.Pvx;
                float vy = f.Vy * speedMul + f.Pvy;
                float decay = 1f - Math.Min(1f, dt * 2.2f);
                f.Pvx *= decay; f.Pvy *= decay;
                f.X += vx * dt; f.Y += vy * dt;

                if (f.Y > H + 12 || (f.X > W + 40 && vx > 0) || (f.X < -40 && vx < 0)) { Spawn(f, false); continue; }
                if (f.Y < 0) continue;

                for (int k = 0; k < zlist.Count; k++)
                {
                    Surface s = zlist[k];
                    Rectangle r = s.R;
                    if (f.X >= r.Left && f.X < r.Right && f.Y >= r.Top && f.Y < r.Bottom)
                    {
                        if (accumulate && f.Y - r.Top < 14f * dpi + vy * dt)
                        {
                            int bi = (int)((f.X - r.Left) / Surface.B);
                            AddSnow(s, bi, 1.0f * (0.5f + 0.2f * f.Sz) * dpi);
                        }
                        Spawn(f, false);
                        break;
                    }
                }
            }
            initialFill = false;

            for (int i = 0; i < puffs.Length; i++)
            {
                Puff p = puffs[i];
                if (!p.Alive) continue;
                p.Life -= dt;
                if (p.Life <= 0) { p.Alive = false; continue; }
                p.Vy += 260f * dpi * dt;
                p.Vx *= 1f - Math.Min(1f, dt * 1.5f);
                p.X += p.Vx * dt; p.Y += p.Vy * dt;
            }
        }

        bool sweepOn = false;
        int sweepX = 0, sweepY = 0;

        void Sweep(float dt, int cx, int cy, int active)
        {
            float R = 70f * dpi;
            foreach (Surface s in zlist)
            {
                Rectangle r = s.R;
                if (cy < r.Top - R || cy > r.Top + R * 0.6f) continue;
                if (cx < r.Left - R || cx > r.Right + R) continue;
                float[] h = s.H;
                int j0 = Math.Max(0, (int)((cx - R - r.Left) / Surface.B));
                int j1 = Math.Min(h.Length - 1, (int)((cx + R - r.Left) / Surface.B));
                for (int j = j0; j <= j1; j++)
                {
                    float x = r.Left + j * Surface.B + Surface.B * 0.5f;
                    float d = Math.Abs(x - cx) / R;
                    if (d >= 1f || h[j] <= 0.02f) continue;
                    float cut = h[j] * Math.Min(1f, dt * 10f * (1f - d));
                    h[j] -= cut;
                    if (cut > 0.04f && rnd.NextDouble() < cut * 1.4)
                    {
                        float dir = x < cx ? -1f : 1f;
                        SpawnPuff(x, r.Top - h[j], dir * (60f + (float)rnd.NextDouble() * 160f) * dpi,
                            -(40f + (float)rnd.NextDouble() * 120f) * dpi);
                    }
                }
                foreach (Snowman m in s.Men)
                    if (Math.Abs(r.Left + m.X - cx) < R * 0.35f && cy > r.Top - 90 * dpi && cy < r.Top + 10 * dpi)
                        m.X = -9999;   // смахнули снеговика
                s.Men.RemoveAll(delegate (Snowman m) { return m.X < -9000; });
            }
            for (int i = 0; i < active; i++)
            {
                Flake f = flakes[i];
                float dx = f.X - cx, dy = f.Y - cy, d2 = dx * dx + dy * dy;
                if (d2 < R * R && d2 > 1f)
                {
                    float d = (float)Math.Sqrt(d2);
                    f.Pvx += dx / d * 900f * dt; f.Pvy += dy / d * 900f * dt;
                }
            }
        }

        void ClearAllSnow()
        {
            foreach (Surface s in zlist)
            {
                float[] h = s.H;
                for (int j = 0; j < h.Length; j += 2)
                    if (h[j] > 1.2f && rnd.NextDouble() < 0.4)
                        SpawnPuff(s.R.Left + j * Surface.B, s.R.Top - h[j],
                            ((float)rnd.NextDouble() - 0.5f) * 240f * dpi, -(20f + (float)rnd.NextDouble() * 140f) * dpi);
            }
            foreach (Surface s in surf.Values) Array.Clear(s.H, 0, s.H.Length);
        }

        void AddSnowman()
        {
            List<Surface> c = new List<Surface>();
            foreach (Surface s in zlist)
                if (!s.Ground && s.R.Top > 90 * dpi && s.R.Width > 220 && s.R.Left < W - 120) c.Add(s);
            if (c.Count == 0) foreach (Surface s in zlist) if (s.Ground) c.Add(s);
            if (c.Count == 0) return;
            Surface t2 = c[rnd.Next(c.Count)];
            Snowman m = new Snowman();
            m.X = 50f * dpi + (float)rnd.NextDouble() * Math.Max(10f, t2.R.Width - 110f * dpi);
            m.Scale = (0.85f + (float)rnd.NextDouble() * 0.35f) * dpi;
            m.Hat = rnd.Next(3);
            m.Scarf = palette[rnd.Next(palette.Length)];
            t2.Men.Add(m);
            if (t2.Men.Count > 6) t2.Men.RemoveAt(0);
        }

        // ============================================================ отрисовка
        void ClipFor(int idx, Rectangle bounds)
        {
            g.ResetClip();
            for (int j = 0; j < idx; j++)
            {
                Rectangle r = zlist[j].R;
                if (r.IntersectsWith(bounds)) g.ExcludeClip(r);
            }
        }

        void Render()
        {
            g.ResetClip();
            g.CompositingMode = CompositingMode.SourceCopy;
            g.Clear(Color.Transparent);
            g.CompositingMode = CompositingMode.SourceOver;

            int up = (int)(110 * dpi);
            for (int i = 0; i < zlist.Count; i++)
            {
                Surface s = zlist[i];
                bool hasSnow = false;
                float[] h = s.H;
                for (int j = 0; j < h.Length; j++) if (h[j] > 0.3f) { hasSnow = true; break; }
                if (!hasSnow && s.Men.Count == 0) continue;
                Rectangle pb = new Rectangle(s.R.Left - 10, s.R.Top - up, s.R.Width + 20, up + (int)(6 * dpi));
                if (pb.Bottom < 0 || pb.Top > H) continue;
                ClipFor(i, pb);
                if (hasSnow) DrawPile(s);
                foreach (Snowman m in s.Men)
                {
                    if (m.X > s.R.Width - 10) continue;
                    int bi = Math.Max(0, Math.Min(h.Length - 1, (int)(m.X / Surface.B)));
                    DrawSnowman(s.R.Left + m.X, s.R.Top - h[bi] + 3f * dpi, m.Scale, m);
                }
            }
            g.ResetClip();

            // снежинки
            for (int i = 0; i < lastActive; i++)
            {
                Flake f = flakes[i];
                if (!f.Alive || f.Y < -8) continue;
                Bitmap b = spr[f.Sz, f.Al];
                int S = b.Width;
                g.DrawImage(b, new RectangleF(f.X - S / 2f, f.Y - S / 2f, S, S), new RectangleF(0, 0, S, S), GraphicsUnit.Pixel);
            }

            // облачка от смахивания
            for (int i = 0; i < puffs.Length; i++)
            {
                Puff p = puffs[i];
                if (!p.Alive) continue;
                int al = p.Life > p.Max * 0.66f ? 2 : (p.Life > p.Max * 0.33f ? 1 : 0);
                Bitmap b = spr[p.Sz + 1, al];
                int S = b.Width;
                g.DrawImage(b, new RectangleF(p.X - S / 2f, p.Y - S / 2f, S, S), new RectangleF(0, 0, S, S), GraphicsUnit.Pixel);
            }

            // кольцо «варежки»
            if (sweepOn)
            {
                float R = 70f * dpi;
                using (SolidBrush sb = new SolidBrush(Color.FromArgb(26, 255, 255, 255)))
                    g.FillEllipse(sb, sweepX - R, sweepY - R, 2 * R, 2 * R);
                using (Pen pn = new Pen(Color.FromArgb(120, 255, 255, 255), 2f))
                    g.DrawEllipse(pn, sweepX - R, sweepY - R, 2 * R, 2 * R);
            }
        }

        void DrawPile(Surface s)
        {
            float[] h = s.H; int n = h.Length;
            if (sm.Length < n) sm = new float[n];
            for (int j = 0; j < n; j++)
            {
                float a = h[j > 0 ? j - 1 : j], c = h[j], d = h[j < n - 1 ? j + 1 : j];
                sm[j] = (a + 2f * c + d) * 0.25f;
            }
            int j0 = 0;
            while (j0 < n)
            {
                if (sm[j0] <= 0.25f) { j0++; continue; }
                int j1 = j0;
                while (j1 < n && sm[j1] > 0.25f) j1++;
                DrawRun(s, j0, j1);
                j0 = j1;
            }
        }

        void DrawRun(Surface s, int j0, int j1)
        {
            int cnt = j1 - j0;
            float L = s.R.Left, T = s.R.Top;
            float xs = L + j0 * Surface.B, xe = L + j1 * Surface.B;
            PointF[] poly = new PointF[cnt + 4];
            PointF[] edge = new PointF[cnt];
            float runMax = 0f;
            poly[0] = new PointF(xs, T);
            for (int k = 0; k < cnt; k++)
            {
                float y = T - sm[j0 + k];
                if (sm[j0 + k] > runMax) runMax = sm[j0 + k];
                PointF p = new PointF(L + (j0 + k) * Surface.B + Surface.B * 0.5f, y);
                poly[k + 1] = p; edge[k] = p;
            }
            poly[cnt + 1] = new PointF(xe, T);
            poly[cnt + 2] = new PointF(xe, T + 3f * dpi);
            poly[cnt + 3] = new PointF(xs, T + 3f * dpi);

            // мягкая тень под сугробом
            using (Pen sp = new Pen(Color.FromArgb(70, 40, 70, 110), 2.5f * dpi))
                g.DrawLine(sp, xs, T + 1f, xe, T + 1f);

            using (LinearGradientBrush br = new LinearGradientBrush(
                new RectangleF(xs, T - runMax - 1f, Math.Max(2f, xe - xs), runMax + 5f * dpi),
                Color.FromArgb(252, 253, 255), Color.FromArgb(206, 220, 241), 90f))
                g.FillPolygon(br, poly);

            if (cnt >= 2)
                using (Pen ep = new Pen(Color.FromArgb(150, 168, 194, 226), 1.1f))
                    g.DrawLines(ep, edge);
        }

        void Ball(float cx, float cy, float r)
        {
            using (GraphicsPath p = new GraphicsPath())
            {
                p.AddEllipse(cx - r, cy - r, 2 * r, 2 * r);
                using (PathGradientBrush pg = new PathGradientBrush(p))
                {
                    pg.CenterPoint = new PointF(cx - r * 0.35f, cy - r * 0.4f);
                    pg.CenterColor = Color.FromArgb(255, 255, 255);
                    pg.SurroundColors = new Color[] { Color.FromArgb(194, 212, 238) };
                    g.FillPath(pg, p);
                }
                using (Pen pen = new Pen(Color.FromArgb(120, 140, 170, 205), 1f)) g.DrawPath(pen, p);
            }
        }

        void DrawSnowman(float cx, float by, float s, Snowman m)
        {
            float r1 = 15f * s, r2 = 11f * s, r3 = 8f * s;
            float y1 = by - r1 + 1.5f * s;
            float y2 = y1 - r1 * 0.8f - r2 * 0.8f;
            float y3 = y2 - r2 * 0.78f - r3 * 0.78f;

            using (SolidBrush sh = new SolidBrush(Color.FromArgb(46, 40, 70, 110)))
                g.FillEllipse(sh, cx - r1 * 1.15f, by - r1 * 0.18f, r1 * 2.3f, r1 * 0.4f);

            using (Pen arm = new Pen(Color.FromArgb(110, 76, 48), Math.Max(1.2f, 1.5f * s)))
            {
                arm.StartCap = LineCap.Round; arm.EndCap = LineCap.Round;
                g.DrawLine(arm, cx - r2 * 0.7f, y2 - r2 * 0.1f, cx - r2 * 2.0f, y2 - r2 * 1.0f);
                g.DrawLine(arm, cx - r2 * 1.5f, y2 - r2 * 0.65f, cx - r2 * 1.65f, y2 - r2 * 1.15f);
                g.DrawLine(arm, cx + r2 * 0.7f, y2 - r2 * 0.1f, cx + r2 * 2.0f, y2 - r2 * 0.9f);
                g.DrawLine(arm, cx + r2 * 1.5f, y2 - r2 * 0.6f, cx + r2 * 1.7f, y2 - r2 * 1.1f);
            }

            Ball(cx, y1, r1); Ball(cx, y2, r2); Ball(cx, y3, r3);

            using (SolidBrush coal = new SolidBrush(Color.FromArgb(36, 40, 52)))
            {
                float br = 1.4f * s;
                g.FillEllipse(coal, cx - br, y2 - r2 * 0.4f - br, 2 * br, 2 * br);
                g.FillEllipse(coal, cx - br, y2 + r2 * 0.1f - br, 2 * br, 2 * br);
                g.FillEllipse(coal, cx - br, y1 - r1 * 0.2f - br, 2 * br, 2 * br);
                float er = 1.15f * s;
                g.FillEllipse(coal, cx - r3 * 0.38f - er, y3 - r3 * 0.22f - er, 2 * er, 2 * er);
                g.FillEllipse(coal, cx + r3 * 0.38f - er, y3 - r3 * 0.22f - er, 2 * er, 2 * er);
            }

            // нос-морковка
            using (SolidBrush nose = new SolidBrush(Color.FromArgb(240, 128, 30)))
                g.FillPolygon(nose, new PointF[] {
                    new PointF(cx - r3 * 0.12f, y3 + r3 * 0.02f),
                    new PointF(cx + r3 * 1.15f, y3 + r3 * 0.2f),
                    new PointF(cx - r3 * 0.12f, y3 + r3 * 0.34f) });

            // шарф
            using (SolidBrush sc = new SolidBrush(m.Scarf))
            {
                g.FillRectangle(sc, cx - r3 * 0.85f, y3 + r3 * 0.72f, r3 * 1.7f, 3.4f * s);
                g.FillRectangle(sc, cx + r3 * 0.35f, y3 + r3 * 0.72f, 3.4f * s, 9f * s);
            }

            // шапка
            if (m.Hat == 0)
            {
                using (SolidBrush hb = new SolidBrush(Color.FromArgb(38, 40, 54)))
                {
                    g.FillEllipse(hb, cx - r3 * 1.05f, y3 - r3 * 0.95f, r3 * 2.1f, 3.4f * s);
                    g.FillRectangle(hb, cx - r3 * 0.6f, y3 - r3 * 0.95f - 9f * s, r3 * 1.2f, 9.8f * s);
                }
                using (SolidBrush band = new SolidBrush(m.Scarf))
                    g.FillRectangle(band, cx - r3 * 0.6f, y3 - r3 * 0.95f - 2.6f * s, r3 * 1.2f, 2.6f * s);
            }
            else if (m.Hat == 1)
            {
                using (SolidBrush hb = new SolidBrush(m.Scarf))
                    g.FillPie(hb, cx - r3 * 1.02f, y3 - r3 * 1.02f, r3 * 2.04f, r3 * 2.04f, 180, 180);
                using (SolidBrush w = new SolidBrush(Color.White))
                {
                    g.FillRectangle(w, cx - r3 * 1.02f, y3 - r3 * 0.12f, r3 * 2.04f, 2.6f * s);
                    g.FillEllipse(w, cx - 2.4f * s, y3 - r3 * 1.02f - 3.6f * s, 4.8f * s, 4.8f * s);
                }
            }
        }

        void Present()
        {
            POINT dst = new POINT(vs.X, vs.Y);
            SIZE sz = new SIZE(W, H);
            POINT src = new POINT(0, 0);
            BLENDFUNCTION bf = new BLENDFUNCTION();
            bf.BlendOp = 0; bf.BlendFlags = 0; bf.SourceConstantAlpha = 255; bf.AlphaFormat = 1;
            Native.UpdateLayeredWindow(form.Handle, IntPtr.Zero, ref dst, ref sz, memDC, ref src, 0, ref bf, 2);
        }

        // ============================================================ кадр
        void Frame()
        {
            double now = clock.Elapsed.TotalSeconds;
            float dt = (float)(now - last);
            last = now;
            if (dt > 0.05f) dt = 0.05f;
            if (dt <= 0f) return;

            if (now >= nextCheck)
            {
                nextCheck = now + 0.5;
                if (!paused) { fullscreen = IsFullscreenForeground(); }
                ApplyVisibility();
            }
            if (!shown) return;

            if (now >= nextTop)
            {
                nextTop = now + 0.5;
                Native.SetWindowPos(form.Handle, new IntPtr(-1), 0, 0, 0, 0, 0x13); // TOPMOST, без активации
            }

            frameNo++;
            BuildSurfaces(now);
            Simulate(dt);
            Render();
            Present();
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            bool created;
            using (Mutex m = new Mutex(true, "Local\\FlakeSnow_SingleInstance_v1", out created))
            {
                if (!created) return;

                bool ok = false;
                try { ok = Native.SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch (Exception) { }   // Per-Monitor V2
                if (!ok) { try { Native.SetProcessDPIAware(); } catch (Exception) { } }

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new SnowApp());
            }
        }
    }
}
